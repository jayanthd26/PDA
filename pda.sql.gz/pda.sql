-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: pda
-- ------------------------------------------------------
-- Server version	5.7.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `fca_id` int(11) NOT NULL AUTO_INCREMENT,
  `usn` varchar(14) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`fca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES (45,'01Jst17cs067','jeevanth','jeevanthdayalu@gmail.com','12345'),(46,'01jst17cs095','Nanda','nandakrishnaks.achar@gmail.com','nanda'),(47,'01234','nagarjun','jeevanthdayalu@gmail.com','1234');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score`
--

DROP TABLE IF EXISTS `score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score` (
  `test_id` int(11) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `answers` text,
  `tot_marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score`
--

LOCK TABLES `score` WRITE;
/*!40000 ALTER TABLE `score` DISABLE KEYS */;
INSERT INTO `score` VALUES (95,123,'Hsbdndndn`~#%',2);
/*!40000 ALTER TABLE `score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usn` varchar(12) NOT NULL,
  `class` varchar(10) NOT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (47,'naga','12345','naga@gmail.com','01Jst17cs092','1'),(48,'naga2','naga2','naga2@gmail.com','naga2','2'),(49,'jayanth d','12345678','jayanthd26@gmail.com','01jst17cs064','1'),(50,'jayanth d','12345678','jayanthd26@gmail.com','01jst17cs064','1'),(51,'qwe','123','134','123','1');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `fca_usn` varchar(15) NOT NULL,
  `questions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sta_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `tname` varchar(50) NOT NULL,
  `tcode` varchar(15) NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES (91,'01Jst17cs067','haii~`#^1,,,1,,,1,,,1,,,a~`^Tagaga\n~`^','2020-05-27 12:11:00','2020-05-27 12:15:00','test','1'),(92,'01Jst17cs067','qwee~`#^1,,,2,,,3,,,4,,,a~`^hshshs~`#^1,,,2,,,3,,,4,,,b~`^Hshshs~`^Yshshs~`^','2020-05-27 12:14:00','2020-05-27 12:20:00','hsh','2'),(93,'01Jst17cs067','1~`#^1,,,1,,,1,,,1,,,d~`^2~`#^2,,,2,,,2,,,2,,,c~`^Hhhhhhhh\n~`^','2020-05-27 12:24:00','2020-05-27 12:30:00','final','2'),(94,'','What is your name~`#^Nanda,,,Jaya,,,jeeva,,,naga,,,a~`^Select a option~`#^a,,,b,,,c,,,d,,,d~`^Tell me about urself\n~`^','2020-05-27 12:53:00','2020-05-27 12:57:00','Test','1'),(95,'','1~`#^1,,,11,,,1,,,4,,,d~`^Gehrvsn~`^2~`#^2,,,2,,,2,,,2,,,c~`^Fwgend ~`^','2020-05-27 13:23:00','2020-05-27 13:30:00','pgydc','1');
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-11  7:24:55
